import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgMasonryComponent } from './ng-masonry.component';

describe('NgMasonryComponent', () => {
  let component: NgMasonryComponent;
  let fixture: ComponentFixture<NgMasonryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgMasonryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgMasonryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
