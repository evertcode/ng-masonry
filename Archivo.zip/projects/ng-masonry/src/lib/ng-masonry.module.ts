import { NgModule } from '@angular/core';
import { NgMasonryComponent } from './ng-masonry.component';
import { NgMasonryDirective } from './ng-masonry.directive';

@NgModule({
  declarations: [NgMasonryComponent, NgMasonryDirective],
  imports: [
  ],
  exports: [NgMasonryComponent, NgMasonryDirective]
})
export class NgMasonryModule { }
